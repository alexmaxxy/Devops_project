﻿namespace MMA.WebApi.DataAccess.Models
{
    public class CompanyActivity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CompanyId { get; set; }
    }
}
