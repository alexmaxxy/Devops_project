﻿namespace MMA.WebApi.DataAccess.Models
{
    public class CompanyPartner
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CompanyId { get; set; }
    }
}
