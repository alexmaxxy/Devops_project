﻿namespace MMA.WebApi.DataAccess.Models
{
    public class AcceptedDomain
    {
        public string Id { get; set; }
        public string Domain { get; set; }
    }
}
